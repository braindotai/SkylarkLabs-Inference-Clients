# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['skylarklabs_inference_client',
 'skylarklabs_inference_client.production_clients',
 'skylarklabs_inference_client.standard_clients',
 'skylarklabs_inference_client.utils']

package_data = \
{'': ['*']}

install_requires = \
['attrdict>=2.0.1,<3.0.0',
 'numpy>=1.24.1,<2.0.0',
 'onnxruntime-gpu>=1.13.1,<2.0.0',
 'opencv-contrib-python>=4.6.0.66,<5.0.0.0',
 'pillow>=9.3.0,<10.0.0',
 'requests>=2.28.1,<3.0.0',
 'rich>=12.6.0,<13.0.0',
 'torch>=1.13.1,<2.0.0',
 'torchvision>=0.14.1,<0.15.0',
 'tritonclient[grpc]>=2.29.0,<3.0.0']

setup_kwargs = {
    'name': 'skylarklabs-inference-client',
    'version': '0.1.0',
    'description': 'Inference client library for running production deep learning models on both Triton Inference Server and Monolythic ONNX Server',
    'long_description': "# Skylarklabs Triton Inference's Client Library",
    'author': 'Rishik Mourya',
    'author_email': 'rishik@skylarklabs.ai',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '==3.9.16',
}


setup(**setup_kwargs)
